# Security Policy

## Supported Versions

| Version  | Supported          |
|----------| ------------------ |
| \>=1.0.0 | :white_check_mark: |

## Reporting a Vulnerability

If you like to report a vulnerability in private, please contact us with a private message on GitHub.
