
============
Enumerations
============

.. cpp::namespace:: erbsland::qt::toml

The ``LocationFormat`` Enum Class
=================================

.. index::
    !single: LocationFormat

.. doxygenenum:: LocationFormat

The ``Specification`` Enum Class
================================

.. index::
    !single: Specification

.. doxygenenum:: Specification

.. doxygenfunction:: specificationToString

The ``ValueType`` Enum Class
============================

.. index::
    !single: ValueType

.. doxygenenum:: ValueType

.. doxygenfunction:: valueTypeToString

.. doxygenfunction:: valueTypeToUnitTestString


The ``ValueSource`` Enum Class
==============================

.. index::
    !single: ValueSource

.. doxygenenum:: ValueSource

.. doxygenfunction:: valueSourceToString

