
=======
Classes
=======

The ``Error`` Class
===================

.. doxygenclass:: erbsland::qt::toml::Error
    :members:

The ``InputStream`` Class
=========================

.. doxygenclass:: erbsland::qt::toml::InputStream
    :members:

The ``Char`` Class
==================

.. doxygenclass:: erbsland::qt::toml::Char
    :members:

The ``Location`` Class
======================

.. doxygenclass:: erbsland::qt::toml::Location
    :members:

The ``LocationRange`` Class
===========================

.. doxygenclass:: erbsland::qt::toml::LocationRange
    :members:

The ``Parser`` Class
====================

.. doxygenclass:: erbsland::qt::toml::Parser
    :members:

The ``Value`` Class
===================

.. doxygentypedef:: erbsland::qt::toml::ValuePtr

.. doxygenclass:: erbsland::qt::toml::Value
    :members:
