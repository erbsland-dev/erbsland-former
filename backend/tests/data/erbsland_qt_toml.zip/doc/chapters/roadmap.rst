
=======
Roadmap
=======

- Version 1.4: Adding a schema to verify loaded TOML configuration documents.
- Version 1.6: Adding a TOML serializer.

